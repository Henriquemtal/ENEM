'use server';

/**
 * @fileOverview Generates benefit-driven copy for the landing page.
 *
 * - generateBenefitDrivenCopy - A function that generates persuasive copy.
 * - GenerateBenefitDrivenCopyInput - The input type for the generateBenefitDrivenCopy function.
 * - GenerateBenefitDrivenCopyOutput - The return type for the generateBenefitDrivenCopy function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateBenefitDrivenCopyInputSchema = z.object({
  productName: z.string().describe('The name of the product.'),
  targetAudience: z.string().describe('The target audience for the product.'),
  productBenefits: z
    .string()
    .describe('A list of benefits that the product provides, separated by commas.'),
  tone: z.string().optional().describe('The tone of the copy (e.g., urgent, friendly, professional).'),
});
export type GenerateBenefitDrivenCopyInput = z.infer<typeof GenerateBenefitDrivenCopyInputSchema>;

const GenerateBenefitDrivenCopyOutputSchema = z.object({
  headline: z.string().describe('A compelling headline for the landing page.'),
  body: z.string().describe('Benefit-driven copy for the landing page.'),
});
export type GenerateBenefitDrivenCopyOutput = z.infer<typeof GenerateBenefitDrivenCopyOutputSchema>;

export async function generateBenefitDrivenCopy(
  input: GenerateBenefitDrivenCopyInput
): Promise<GenerateBenefitDrivenCopyOutput> {
  return generateBenefitDrivenCopyFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateBenefitDrivenCopyPrompt',
  input: {schema: GenerateBenefitDrivenCopyInputSchema},
  output: {schema: GenerateBenefitDrivenCopyOutputSchema},
  prompt: `You are an expert copywriter specializing in creating high-converting landing page copy.

  Based on the product name, target audience and benefits, create a compelling headline and benefit-driven copy for a landing page.
  Incorporate elements of scarcity, social proof, and authority where appropriate.
  The tone of the copy should be {{tone}}.

  Product Name: {{productName}}
  Target Audience: {{targetAudience}}
  Benefits: {{productBenefits}}

  Headline:
  Body:
  `,
});

const generateBenefitDrivenCopyFlow = ai.defineFlow(
  {
    name: 'generateBenefitDrivenCopyFlow',
    inputSchema: GenerateBenefitDrivenCopyInputSchema,
    outputSchema: GenerateBenefitDrivenCopyOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
