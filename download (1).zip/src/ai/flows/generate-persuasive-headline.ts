'use server';
/**
 * @fileOverview Generates persuasive headlines for a landing page using AI, incorporating benefits, scarcity, and social proof.
 *
 * - generatePersuasiveHeadline - A function that generates persuasive headlines.
 * - GeneratePersuasiveHeadlineInput - The input type for the generatePersuasiveHeadline function.
 * - GeneratePersuasiveHeadlineOutput - The return type for the generatePersuasiveHeadline function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GeneratePersuasiveHeadlineInputSchema = z.object({
  productName: z.string().describe('The name of the product.'),
  targetAudience: z.string().describe('The target audience for the product.'),
  keyBenefits: z.string().describe('A comma-separated list of key benefits of the product.'),
  scarcityStatement: z.string().describe('A statement indicating scarcity (e.g., \'Limited time offer\').'),
  socialProof: z.string().describe('A statement providing social proof (e.g., \'Join 10,000+ satisfied customers\').'),
});
export type GeneratePersuasiveHeadlineInput = z.infer<typeof GeneratePersuasiveHeadlineInputSchema>;

const GeneratePersuasiveHeadlineOutputSchema = z.object({
  headlines: z.array(z.string()).describe('An array of persuasive headlines.'),
});
export type GeneratePersuasiveHeadlineOutput = z.infer<typeof GeneratePersuasiveHeadlineOutputSchema>;

export async function generatePersuasiveHeadline(input: GeneratePersuasiveHeadlineInput): Promise<GeneratePersuasiveHeadlineOutput> {
  return generatePersuasiveHeadlineFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generatePersuasiveHeadlinePrompt',
  input: {schema: GeneratePersuasiveHeadlineInputSchema},
  output: {schema: GeneratePersuasiveHeadlineOutputSchema},
  prompt: `You are a marketing expert specializing in writing persuasive headlines.
  Generate multiple compelling headlines for our landing page, incorporating the following elements:

  Product Name: {{{productName}}}
  Target Audience: {{{targetAudience}}}
  Key Benefits: {{{keyBenefits}}}
  Scarcity Statement: {{{scarcityStatement}}}
  Social Proof: {{{socialProof}}}

  The headlines should be concise, attention-grabbing, and benefit-driven. Provide at least 3 different options.
  Output should be an array of headlines.`,
});

const generatePersuasiveHeadlineFlow = ai.defineFlow(
  {
    name: 'generatePersuasiveHeadlineFlow',
    inputSchema: GeneratePersuasiveHeadlineInputSchema,
    outputSchema: GeneratePersuasiveHeadlineOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
