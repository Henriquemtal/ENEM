'use server';

/**
 * @fileOverview A/B testing flow for landing page headlines and CTAs.
 *
 * - abTestLandingPage - A function that generates and A/B tests landing page content.
 * - ABTestLandingPageInput - The input type for the abTestLandingPage function.
 * - ABTestLandingPageOutput - The return type for the abTestLandingPage function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ABTestLandingPageInputSchema = z.object({
  productDescription: z
    .string()
    .describe('Description of the product being advertised on the landing page.'),
  currentHeadline: z.string().describe('The current headline on the landing page.'),
  currentCTA: z.string().describe('The current call to action on the landing page.'),
});
export type ABTestLandingPageInput = z.infer<typeof ABTestLandingPageInputSchema>;

const ABTestLandingPageOutputSchema = z.object({
  alternativeHeadline1: z.string().describe('An alternative headline suggestion.'),
  alternativeCTA1: z.string().describe('An alternative call to action suggestion.'),
  alternativeHeadline2: z.string().describe('A second alternative headline suggestion.'),
  alternativeCTA2: z.string().describe('A second alternative call to action suggestion.'),
  reasoning: z
    .string()
    .describe(
      'The AI agents reasoning why it suggested these headlines and CTAs based on the product description.'
    ),
});
export type ABTestLandingPageOutput = z.infer<typeof ABTestLandingPageOutputSchema>;

export async function abTestLandingPage(input: ABTestLandingPageInput): Promise<ABTestLandingPageOutput> {
  return abTestLandingPageFlow(input);
}

const prompt = ai.definePrompt({
  name: 'abTestLandingPagePrompt',
  input: {schema: ABTestLandingPageInputSchema},
  output: {schema: ABTestLandingPageOutputSchema},
  prompt: `You are an expert marketer tasked with optimizing landing pages.

  Given the following product description, current headline, and current call to action, generate two alternative headlines and two alternative calls to action.

  Product Description: {{{productDescription}}}
  Current Headline: {{{currentHeadline}}}
  Current Call to Action: {{{currentCTA}}}

  Explain your reasoning for suggesting these alternatives. Try to incorporate principles of persuasive copy, such as scarcity, social proof, and clear benefits.

  Alternative Headline 1:
  Alternative Call to Action 1:
  Alternative Headline 2:
  Alternative Call to Action 2:
  Reasoning:`,
});

const abTestLandingPageFlow = ai.defineFlow(
  {
    name: 'abTestLandingPageFlow',
    inputSchema: ABTestLandingPageInputSchema,
    outputSchema: ABTestLandingPageOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
