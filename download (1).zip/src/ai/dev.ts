import { config } from 'dotenv';
config();

import '@/ai/flows/generate-benefit-driven-copy.ts';
import '@/ai/flows/generate-persuasive-headline.ts';
import '@/ai/flows/ab-test-landing-page.ts';