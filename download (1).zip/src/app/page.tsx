import { Header } from "@/components/landing/header";
import { SummaryPreviews } from "@/components/landing/summary-previews";
import { Benefits } from "@/components/landing/benefits";
import { Testimonials } from "@/components/landing/testimonials";
import { Faq } from "@/components/landing/faq";
import { CtaSection } from "@/components/landing/cta-section";
import { Footer } from "@/components/landing/footer";
import { Vsl } from "@/components/landing/vsl";
import { Price } from "@/components/landing/price";
import { SalesNotification } from "@/components/landing/sales-notification";
import { Subjects } from "@/components/landing/subjects";

export default function Home() {
  return (
    <div className="flex flex-col min-h-[100dvh]">
      <Header />
      <main className="flex-1">
        <Price />
        <SummaryPreviews />
        <Vsl />
        <Subjects />
        <Benefits />
        <Testimonials />
        <Faq />
        <CtaSection />
        <SalesNotification />
      </main>
      <Footer />
    </div>
  );
}
