"use client";
import Image from "next/image";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { Eye } from "lucide-react";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import Autoplay from "embla-carousel-autoplay";

export function SummaryPreviews() {
  const summaryImages = PlaceHolderImages.filter((img) =>
    img.id.startsWith("summary-preview")
  );

  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-background/50">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl text-white font-headline font-bold tracking-tighter sm:text-5xl">
              Veja Como São Nossos Resumos
            </h2>
          </div>
        </div>
        <Carousel
          opts={{ align: "start", loop: true }}
          plugins={[Autoplay({ delay: 3000, stopOnInteraction: false })]}
          className="w-full max-w-xs sm:max-w-sm md:max-w-md lg:max-w-lg mx-auto pt-12"
        >
          <CarouselContent>
            {summaryImages.map((image, index) => (
              <CarouselItem key={index}>
                <Dialog>
                  <DialogTrigger asChild>
                    <div className="group relative cursor-pointer overflow-hidden rounded-lg shadow-lg transition-transform hover:scale-105">
                      <Image
                        src={image.imageUrl}
                        alt={image.description}
                        width={731}
                        height={1024}
                        className="object-cover w-full h-full"
                        data-ai-hint={image.imageHint}
                      />
                      <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <Eye className="h-8 w-8 text-white" />
                        <p className="text-white font-bold mt-2">Ver Mais</p>
                      </div>
                    </div>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[731px] p-0 border-0 bg-transparent shadow-none">
                    <Image
                      src={image.imageUrl}
                      alt={image.description}
                      width={731}
                      height={1024}
                      className="object-contain rounded-lg"
                      data-ai-hint={image.imageHint}
                    />
                  </DialogContent>
                </Dialog>
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious className="-left-4 md:-left-8 text-white border-white/50 hover:bg-white/20" />
          <CarouselNext className="-right-4 md:-right-8 text-white border-white/50 hover:bg-white/20" />
        </Carousel>
      </div>
    </section>
  );
}
