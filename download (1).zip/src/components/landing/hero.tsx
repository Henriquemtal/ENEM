import Image from "next/image";
import { Button } from "@/components/ui/button";
import { PlaceHolderImages } from "@/lib/placeholder-images";

export function Hero() {
  const heroImage = PlaceHolderImages.find((img) => img.id === "hero-image");

  return (
    <section className="relative w-full py-12 md:py-24 lg:py-32">
      <div className="container px-4 md:px-6">
        <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
          <div className="flex flex-col justify-center space-y-4">
            <div className="space-y-4">
              <h1 className="font-headline text-4xl font-extrabold tracking-tighter sm:text-5xl xl:text-6xl/none bg-clip-text text-transparent bg-gradient-to-r from-primary to-accent">
                Passe no ENEM 2025 Estudando Menos e Aprendendo Mais
              </h1>
              <p className="max-w-[600px] text-muted-foreground md:text-xl">
                Tenha acesso a +400 resumos completos e otimizados que já
                ajudaram milhares de estudantes a alcançar a aprovação dos
                sonhos.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Button
                asChild
                size="lg"
                className="font-bold text-lg shadow-lg hover:shadow-xl transition-shadow"
              >
                <a href="#cta">
                  <span>Quero Garantir Meu Acesso Agora</span>
                  <span className="text-sm font-normal opacity-90 ml-2">
                    (Oferta Limitada!)
                  </span>
                </a>
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Garantia de 7 dias. Acesso imediato.
            </p>
          </div>
          <div className="relative aspect-video lg:aspect-square overflow-hidden rounded-xl shadow-2xl">
            {heroImage && (
              <Image
                src={heroImage.imageUrl}
                alt={heroImage.description}
                fill
                className="object-cover"
                data-ai-hint={heroImage.imageHint}
                priority
              />
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
