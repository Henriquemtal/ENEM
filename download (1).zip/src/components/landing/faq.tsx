"use client";

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import * as fbq from "@/components/analytics/facebook-pixel";

const faqs = [
  {
    question: "Como vou receber o acesso aos resumos?",
    answer:
      "O acesso é imediato! Assim que seu pagamento for confirmado, você receberá um e-mail com todas as instruções para acessar a plataforma com os resumos. Simples e rápido.",
  },
  {
    question: "Os resumos servem para qual ano do ENEM?",
    answer:
      "Nossos resumos são 100% atualizados para o ENEM 2025, cobrindo todo o edital e as competências exigidas pela prova. Você estará estudando com o material mais recente do mercado.",
  },
  {
    question: "E se eu não gostar do material?",
    answer:
      "Seu risco é zero! Oferecemos uma garantia incondicional de 7 dias. Se por qualquer motivo você não ficar satisfeito, basta nos enviar um e-mail e devolveremos 100% do seu dinheiro, sem perguntas.",
  },
  {
    question: "Posso imprimir os resumos?",
    answer:
      "Sim! Todos os resumos estão disponíveis em formato PDF de alta qualidade, prontos para você imprimir e estudar onde e como preferir.",
  },
  {
    question: "Por quanto tempo terei acesso?",
    answer:
      "O acesso à plataforma e a todos os bônus é vitalício! Você compra uma vez e pode usar para sempre, incluindo todas as futuras atualizações que fizermos no material.",
  },
];

export function Faq() {

  const handleSupportClick = () => {
    fbq.event('Contact');
    window.open('https://wa.me/PHONE_NUMBER', '_blank');
  }


  return (
    <section className="w-full py-12 md:py-24 lg:py-32">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-headline font-bold tracking-tighter sm:text-5xl text-white">
              Perguntas Frequentes
            </h2>
            <p className="max-w-[900px] text-white/80 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Relaxa, a gente te ajuda. Aqui estão as respostas para as
              perguntas mais comuns.
            </p>
          </div>
        </div>
        <div className="mx-auto max-w-3xl pt-12">
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="bg-card/80 backdrop-blur-sm rounded-lg px-4 mb-4 shadow-md border-0"
              >
                <AccordionTrigger className="text-lg font-semibold text-left hover:no-underline text-white">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-white/80 text-base">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
        <div className="flex flex-col items-center justify-center space-y-4 text-center mt-12">
          <div className="space-y-2">
            <h3 className="text-2xl font-bold text-white">Ainda tem alguma dúvida?</h3>
            <p className="text-white/80">
              Entre em contato com nosso time de suporte no WhatsApp!
            </p>
            <Button 
              onClick={handleSupportClick}
              className="bg-green-500 hover:bg-green-600 text-white font-bold"
            >
              Falar com Suporte
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
