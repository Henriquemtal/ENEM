import { Button } from "@/components/ui/button";

export function CtaSection() {
  return (
    <section id="cta" className="w-full py-12 md:py-24 lg:py-32 bg-background/80">
      <div className="container grid items-center justify-center gap-4 px-4 text-center md:px-6">
        <div className="space-y-4">
          <h2 className="text-3xl font-bold font-headline tracking-tighter sm:text-4xl md:text-5xl text-white">
            Não Perca Esta Oportunidade!
          </h2>
          <p className="mx-auto max-w-[600px] text-white/80 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
            Mais de +400 resumos completos por apenas R$ 15,99
          </p>
        </div>
        <div className="mx-auto w-full max-w-md space-y-2">
        <div className="text-center">
            <p className="text-5xl font-extrabold text-primary">
              R$ 15,99
            </p>
            <p className="text-lg line-through text-white/70">
              R$ 97,00
            </p>
          </div>
          <Button
            asChild
            size="lg"
            className="font-bold text-xl w-full py-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            <a href="https://go.paradisepagbr.com/l71mgfrh2a">
              <span>GARANTIR AGORA - OFERTA LIMITADA</span>
            </a>
          </Button>
          <p className="text-xs text-white/70">
            Compra 100% segura. Acesso imediato. Garantia de 7 dias.
          </p>
        </div>
      </div>
    </section>
  );
}
