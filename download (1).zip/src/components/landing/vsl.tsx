"use client";

import { useEffect } from "react";
import { Button } from "@/components/ui/button";

export function Vsl() {
  useEffect(() => {
    const video = document.getElementById(
      "paradisePlayer_1757755154583"
    ) as HTMLVideoElement;
    const ctaButton = document.getElementById(
      "paradisePlayer_1757755154583CTA"
    );
    const ctaLink = document.getElementById("paradisePlayer_1757755154583CTALink");
     const muteOverlay = document.getElementById(
      "paradisePlayer_1757755154583MuteOverlay"
    );

    if (!video) {
      console.error(
        "Paradise Player: Video element #paradisePlayer_1757755154583 not found."
      );
      return;
    }

    const handleVideoClick = () => {
      if (video.paused) video.play();
      else video.pause();
    };

    video.playbackRate = 1;

    // Start muted
    video.muted = true;
    // Attempt to play, but catch errors silently. The user will click to unmute and play.
    let playPromise = video.play();
    if (playPromise !== undefined) {
        playPromise.catch(error => { /* Autoplay was prevented. User interaction needed. */ });
    }
    
    if (muteOverlay) {
        const unmuteHandler = () => {
            if(video.muted) {
                video.muted = false;
                if (video.paused) {
                    video.currentTime = 0;
                    video.play();
                }
            }
            muteOverlay.style.opacity = "0";
            setTimeout(() => {
              muteOverlay.style.display = "none";
            }, 300);
            if (window.paradiseTracker && window.paradiseTracker.send) {
              window.paradiseTracker.send("unmute");
              if (video.paused) { // only send play if it wasn't playing
                  window.paradiseTracker.send("play");
              }
            }
        };
        // The user has to click on the overlay to unmute
        muteOverlay.addEventListener("click", unmuteHandler, { once: true });
    }
    

    const handleTimeUpdate = () => {
      if (!video.duration) return;
      
      const getPredictiveProgress = (currentTime: number) => {
        return (currentTime / video.duration);
      }
      
      let fakeProgressValue = getPredictiveProgress(video.currentTime);
      const fakeProgressBar = document.getElementById(
        "paradisePlayer_1757755154583FakeProgressBar"
      );
      if(fakeProgressBar) {
        fakeProgressBar.style.width = Math.min(fakeProgressValue, 1) * 100 + "%";
      }


      if (ctaButton && video.duration) {
        let ctaTime = 30;
        if (video.currentTime >= ctaTime && ctaButton.style.display === "none") {
          ctaButton.style.display = "block";
          ctaButton.style.animation = "paradise-fadeInUp 0.5s ease-out forwards";
        }
      }
    };
    
    if(ctaLink){
        const setupUTMTracking = () => {
            if (!ctaLink) return;
            const urlParams = new URLSearchParams(window.location.search);
            const utmKeys = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content'];
            const baseUrl = 'https://go.paradisepagbr.com/l71mgfrh2a';
            try {
                const url = new URL(baseUrl);
                utmKeys.forEach(key => {
                    const param = urlParams.get(key)
                    if (param) { url.searchParams.set(key, param); }
                });
                (ctaLink as HTMLAnchorElement).href = url.toString();
            } catch(e) { (ctaLink as HTMLAnchorElement).href = baseUrl; }
        }
        setupUTMTracking();
    }


    video.addEventListener("timeupdate", handleTimeUpdate);
    video.addEventListener("click", handleVideoClick);


    return () => {
      video.removeEventListener("timeupdate", handleTimeUpdate);
      video.removeEventListener("click", handleVideoClick);
    };
  }, []);

  return (
    <>
      <style>{`
        #paradisePlayer_1757755154583::-webkit-media-controls, #paradisePlayer_1757755154583::-webkit-media-controls-enclosure { display: none !important; }
        @keyframes paradise-fadeInUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes paradise-mute-bounce { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(calc(-10px * var(--animation-intensity))); } }
        .paradise-mute-bounce { animation: paradise-mute-bounce 1.5s ease-in-out infinite; }
        .paradise-player-container * { transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); }
      `}</style>
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-4">
              <h2 className="text-3xl font-headline font-bold tracking-tighter sm:text-5xl text-white">
                Veja Como Os Resumos Vão Te Ajudar
              </h2>
              <p className="max-w-[700px] text-white/80 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Neste vídeo rápido, eu mostro o segredo por trás do método que
                já aprovou milhares de alunos, estudando da forma certa.
              </p>
            </div>
            <div className="w-full max-w-4xl mx-auto pt-8">
              <div
                id="paradisePlayer_1757755154583Container"
                className="paradise-player-container"
                style={{
                  position: "relative",
                  width: "100%",
                  maxWidth: "800px",
                  margin: "20px auto",
                }}
              >
                 <h3 style={{textAlign: 'center', marginBottom: '20px', fontSize: '1.5em', fontWeight: 'bold', color: '#00c27a'}}>+400 RESUMOS EXPLICADOS ENEM 2025</h3>
                <div
                  id="paradisePlayer_1757755154583Wrapper"
                  style={{
                    position: "relative",
                    width: "100%",
                    paddingBottom: "177.78%",
                    background: "#000",
                    borderRadius: "12px",
                    overflow: "hidden",
                    boxShadow: "0 20px 60px rgba(0,0,0,0.4)",
                  }}
                >
                  <video
                    id="paradisePlayer_1757755154583"
                    style={{
                      position: "absolute",
                      top: 0,
                      left: 0,
                      width: "100%",
                      height: "100%",
                      objectFit: "cover",
                      cursor: "pointer",
                    }}
                    playsInline
                    webkit-playsinline="true"
                    preload="auto"
                    onContextMenu={(e) => e.preventDefault()}
                  >
                    <source
                      src="/videos/400 RESUMOS EXPLICADOS ENEM 2025(1080P_HD).mp4"
                      type="video/mp4"
                    />
                    Seu navegador não suporta vídeos HTML5.
                  </video>

                    <div
                    id="paradisePlayer_1757755154583MuteOverlay"
                    style={{
                        position: "absolute",
                        top: 0,
                        left: 0,
                        width: "100%",
                        height: "100%",
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        background: "#000000ff",
                        cursor: "pointer",
                        zIndex: 20,
                        backdropFilter: "blur(2px)",
                    }}
                    >
                    <div
                        id="paradisePlayer_1757755154583MuteButton"
                        className="paradise-mute-bounce"
                        style={{
                        background: "#00c27a",
                        padding: "clamp(1.2rem, 5vw, 2rem) clamp(1.5rem, 7vw, 3rem)",
                        borderRadius: "12px",
                        textAlign: "center",
                        color: "white",
                        transition: "transform 0.3s ease",
                        boxShadow: "0 8px 25px rgba(0,0,0,0.3)",
                        maxWidth: "90vw",
                        boxSizing: "border-box",
                        }}
                    >
                        <div style={{ fontSize: "clamp(0.9rem, 2.5vw, 1.1rem)", fontWeight: 700, marginBottom: "0.5rem" }}>
                        Seu vídeo já começou!
                        </div>
                        <div style={{ marginBottom: "0.6rem" }}>
                        <img
                            src="https://i.postimg.cc/2j9d2jbv/R.png"
                            alt="Unmute"
                            style={{
                            width: "clamp(2.5rem, 8vw, 3.5rem)",
                            height: "clamp(2.5rem, 8vw, 3.5rem)",
                            filter: "brightness(0) invert(1)",
                            display: "inline-block",
                            }}
                        />
                        </div>
                        <div style={{ fontSize: "clamp(0.8rem, 2.2vw, 1rem)", fontWeight: 500, opacity: 0.95 }}>
                        Clique para ativar o som
                        </div>
                    </div>
                    </div>

                  <div
                    id="paradisePlayer_1757755154583FakeProgressContainer"
                    style={{
                      position: "absolute",
                      bottom: "5px",
                      left: "10px",
                      right: "10px",
                      height: "4px",
                      background: "rgba(255,255,255,0.2)",
                      borderRadius: "2px",
                      zIndex: 20,
                      pointerEvents: "none",
                      transition: "bottom 0.3s ease",
                    }}
                  >
                    <div
                      id="paradisePlayer_1757755154583FakeProgressBar"
                      style={{
                        height: "100%",
                        background:
                          "linear-gradient(90deg, #00c27a, #21bfeb)",
                        borderRadius: "2px",
                        width: "0%",
                        boxShadow: "0 0 8px #00c27a80",
                      }}
                    ></div>
                  </div>
                </div>
                 <div id="paradisePlayer_1757755154583CTA" style={{ display: 'none', textAlign: 'center', marginTop: '20px' }}>
                    <a href="https://go.paradisepagbr.com/l71mgfrh2a" id="paradisePlayer_1757755154583CTALink" target="_blank" style={{ background: '#8b5cf6', color: 'white', padding: '15px 30px', borderRadius: '9999px', textDecoration: 'none', fontWeight: 'bold', boxShadow: '0 6px 20px rgba(0,0,0,0.4)', display: 'inline-block' }}>
                        COMPRAR AGORA
                    </a>
                </div>
              </div>
            </div>
            <div className="w-full max-w-md pt-8">
              <Button
                asChild
                size="lg"
                className="font-bold text-xl w-full py-8 shadow-lg bg-primary hover:bg-primary/90 text-primary-foreground hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1"
              >
                <a href="https://go.paradisepagbr.com/l71mgfrh2a">
                  <span>QUERO GARANTIR MEUS RESUMOS E BÔNUS</span>
                </a>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
