"use client";

import { Button } from "@/components/ui/button";
import { CheckCircle2 } from "lucide-react";

export function Price() {
  return (
    <section id="price" className="w-full py-12 md:py-24 lg:py-32">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-6 text-center text-white">
          <div className="space-y-4">
            <h1 className="text-4xl font-extrabold tracking-tighter sm:text-5xl xl:text-6xl/none">
              +400 Resumos Completos <br /> Para o{" "}
              <span className="text-primary">ENEM 2025</span>
            </h1>
            <p className="max-w-[600px] text-white/90 md:text-xl">
              Todo o conteúdo que você precisa para arrasar no ENEM, organizado
              em resumos práticos e didáticos.
            </p>
          </div>
          <div className="bg-card/80 backdrop-blur-sm p-6 rounded-xl w-full max-w-md">
            <div className="text-center text-white">
              <p className="text-lg line-through text-white/70">
                R$ 97,00
              </p>
              <p className="text-6xl font-extrabold text-primary">
                R$ 15,99
              </p>
              <p className="text-sm text-white/80">
                Menos de R$0,04 por resumo!
              </p>
            </div>
          </div>
          <ul className="grid gap-3 py-4 text-left text-lg w-full max-w-md">
            <li className="flex items-center gap-3 bg-card/80 backdrop-blur-sm p-4 rounded-lg">
              <CheckCircle2 className="h-6 w-6 text-primary" />
              <span>11 Matérias Completas</span>
            </li>
            <li className="flex items-center gap-3 bg-card/80 backdrop-blur-sm p-4 rounded-lg">
              <CheckCircle2 className="h-6 w-6 text-primary" />
              <span>Material Atualizado 2025</span>
            </li>
            <li className="flex items-center gap-3 bg-card/80 backdrop-blur-sm p-4 rounded-lg">
              <CheckCircle2 className="h-6 w-6 text-primary" />
              <span>Acesso Imediato</span>
            </li>
          </ul>

          <Button
            asChild
            size="lg"
            className="font-bold text-xl w-full max-w-md py-8 shadow-lg bg-primary hover:bg-primary/90 text-primary-foreground hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1"
          >
            <a href="https://go.paradisepagbr.com/l71mgfrh2a">
              <span>GARANTIR MEUS RESUMOS AGORA</span>
            </a>
          </Button>
          <p className="text-xs text-white/70 text-center">
            Compra 100% segura. Acesso imediato. Garantia incondicional de 7
            dias.
          </p>
        </div>
      </div>
    </section>
  );
}
