import { Book, Brain, Dna, Earth, FlaskConical, Languages, MessageSquare, Microscope, Sigma, Atom, FileText } from "lucide-react";

const subjects = [
  { icon: <Book className="h-8 w-8 text-primary" />, name: "História" },
  { icon: <Earth className="h-8 w-8 text-primary" />, name: "Geografia" },
  { icon: <Brain className="h-8 w-8 text-primary" />, name: "Filosofia" },
  { icon: <Users className="h-8 w-8 text-primary" />, name: "Sociologia" },
  { icon: <Languages className="h-8 w-8 text-primary" />, name: "Português" },
  { icon: <FileText className="h-8 w-8 text-primary" />, name: "Redação" },
  { icon: <FlaskConical className="h-8 w-8 text-primary" />, name: "Química" },
  { icon: <Atom className="h-8 w-8 text-primary" />, name: "Física" },
  { icon: <Dna className="h-8 w-8 text-primary" />, name: "Biologia" },
  { icon: <Sigma className="h-8 w-8 text-primary" />, name: "Matemática" },
  { icon: <MessageSquare className="h-8 w-8 text-primary" />, name: "Inglês" },
];

// Helper component for lucide icons that don't exist
function Users({ className }: { className: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}


export function Subjects() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-headline font-bold tracking-tighter sm:text-5xl text-white">
              11 Matérias Completas
            </h2>
          </div>
        </div>
        <div className="mx-auto grid max-w-4xl grid-cols-2 items-center justify-center gap-8 pt-12 sm:grid-cols-3 md:gap-12 lg:max-w-5xl lg:grid-cols-4">
          {subjects.map((subject) => (
            <div key={subject.name} className="flex flex-col items-center gap-2 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-card/80">
                {subject.icon}
              </div>
              <h3 className="text-lg font-bold text-white/90">{subject.name}</h3>
            </div>
          ))}
           <div key="artes" className="flex flex-col items-center gap-2 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-card/80">
                <Microscope className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-lg font-bold text-white/90">Artes</h3>
            </div>
        </div>
      </div>
    </section>
  );
}
