import { BookCheck, Presentation, Users } from "lucide-react";

const bonuses = [
  {
    icon: <BookCheck className="h-8 w-8 text-accent" />,
    title: "Simulados Exclusivos",
    description:
      "Teste seus conhecimentos com simulados no estilo do ENEM e identifique seus pontos fracos.",
  },
  {
    icon: <Presentation className="h-8 w-8 text-accent" />,
    title: "Dicas de Redação Nota 1000",
    description:
      "Aprenda a estruturar sua redação e a usar os argumentos certos para impressionar os corretores.",
  },
  {
    icon: <Users className="h-8 w-8 text-accent" />,
    title: "Grupo VIP de Alunos",
    description:
      "Junte-se a uma comunidade de estudantes motivados para trocar dicas, tirar dúvidas e se manter focado.",
  },
];

export function Bonuses() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-secondary/50">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <div className="inline-block rounded-lg bg-accent/20 px-3 py-1 text-sm font-semibold text-accent-foreground border border-accent">
              Bônus Exclusivos
            </div>
            <h2 className="text-3xl font-headline font-bold tracking-tighter sm:text-5xl">
              Leve Tudo Isso de Graça Hoje!
            </h2>
            <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Ao garantir seu acesso hoje, você não leva apenas os resumos, mas
              um pacote completo para sua aprovação.
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-4xl items-start gap-8 pt-12 sm:grid-cols-1 md:gap-12 lg:max-w-5xl lg:grid-cols-3">
          {bonuses.map((bonus) => (
            <div key={bonus.title} className="grid gap-2 text-center md:text-left">
              <div className="flex justify-center md:justify-start gap-4 items-center">
                {bonus.icon}
                <h3 className="text-xl font-bold font-headline">
                  {bonus.title}
                </h3>
              </div>
              <p className="text-muted-foreground">{bonus.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
