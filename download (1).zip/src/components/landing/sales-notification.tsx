"use client";

import { useEffect, useState } from "react";
import { ShoppingCart } from "lucide-react";

const notifications = [
  "Maria C. de São Paulo, SP acabou de comprar!",
  "João P. do Rio de Janeiro, RJ garantiu o acesso!",
  "Ana S. de Belo Horizonte, MG aproveitou a oferta!",
  "Lucas G. de Curitiba, PR acabou de se inscrever!",
  "Fernanda L. de Salvador, BA garantiu sua vaga!",
];

export function SalesNotification() {
  const [isVisible, setIsVisible] = useState(false);
  const [currentNotification, setCurrentNotification] = useState("");

  useEffect(() => {
    const showRandomNotification = () => {
      const randomIndex = Math.floor(Math.random() * notifications.length);
      setCurrentNotification(notifications[randomIndex]);
      setIsVisible(true);

      setTimeout(() => {
        setIsVisible(false);
      }, 5000); // Fica visível por 5 segundos
    };

    const interval = setInterval(
      showRandomNotification,
      Math.random() * (15000 - 8000) + 8000 // Mostra a cada 8-15 segundos
    );

    return () => clearInterval(interval);
  }, []);

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-4 left-4 z-50 animate-in fade-in slide-in-from-bottom-10 duration-500">
      <div className="bg-card/80 backdrop-blur-sm border border-white/20 rounded-lg shadow-lg p-4 flex items-center gap-4">
        <div className="bg-primary/20 p-2 rounded-full">
          <ShoppingCart className="h-6 w-6 text-primary" />
        </div>
        <p className="text-sm font-medium text-white">
          {currentNotification}
        </p>
      </div>
    </div>
  );
}
