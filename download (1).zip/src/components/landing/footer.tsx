import { Rocket } from "lucide-react";

export function Footer() {
  return (
    <footer className="w-full py-6 md:px-8 md:py-12 bg-background/50">
      <div className="container flex items-center justify-center">
        <div className="flex items-center gap-2">
          <Rocket className="h-5 w-5 text-white/60" />
          <p className="text-sm text-white/60">
            &copy; {new Date().getFullYear()} ENEM Rocket. Todos os direitos
            reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}
