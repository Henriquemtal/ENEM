import { Rocket } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-white/10 bg-background/30 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 max-w-screen-2xl items-center justify-between">
        <Link href="/" className="flex items-center space-x-2">
          <Rocket className="h-6 w-6 text-primary" />
          <span className="font-bold font-headline text-lg text-white">ENEM Rocket</span>
        </Link>
        <Button asChild className="font-bold bg-primary hover:bg-primary/90 text-primary-foreground">
          <a href="https://go.paradisepagbr.com/l71mgfrh2a">Quero Minha Aprovação</a>
        </Button>
      </div>
    </header>
  );
}
