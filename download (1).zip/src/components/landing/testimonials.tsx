"use client";
import Image from "next/image";
import { Card, CardContent } from "@/components/ui/card";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import Autoplay from "embla-carousel-autoplay";

const testimonials = PlaceHolderImages.filter(img => img.id.startsWith('testimonial-'));

export function Testimonials() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-background/50">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-headline font-bold tracking-tighter sm:text-5xl text-white">
              O Que Nossos Alunos Dizem
            </h2>
            <p className="max-w-[900px] text-white/80 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Veja o que nossos alunos aprovados estão dizendo. A sua história
              de sucesso pode ser a próxima.
            </p>
          </div>
        </div>
        <Carousel
          opts={{ align: "start", loop: true }}
          plugins={[Autoplay({ delay: 4000, stopOnInteraction: false })]}
          className="w-full max-w-xs sm:max-w-sm md:max-w-lg lg:max-w-xl mx-auto pt-12"
        >
          <CarouselContent>
            {testimonials.map((testimonial, index) => (
              <CarouselItem key={index}>
                <div className="p-1 h-full">
                  <Card className="shadow-lg h-full bg-transparent overflow-hidden border-0 rounded-lg">
                    <CardContent className="p-0">
                      <Image
                        src={testimonial.imageUrl}
                        alt={testimonial.description}
                        width={720}
                        height={501}
                        className="object-contain w-full h-full"
                        data-ai-hint={testimonial.imageHint}
                      />
                    </CardContent>
                  </Card>
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious className="-left-4 md:-left-8 text-white border-white/50 hover:bg-white/20" />
          <CarouselNext className="-right-4 md:-right-8 text-white border-white/50 hover:bg-white/20" />
        </Carousel>
      </div>
    </section>
  );
}
