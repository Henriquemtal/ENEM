import { Award, Clock, Smile } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const benefits = [
  {
    icon: <Award className="h-10 w-10 text-primary" />,
    title: "Economize Tempo",
    description:
      "Domine o conteúdo essencial e veja suas notas decolarem com um material focado no que realmente importa.",
  },
  {
    icon: <Clock className="h-10 w-10 text-primary" />,
    title: "Qualidade Garantida",
    description:
      "Estude de forma mais inteligente, não mais difícil. Ganhe horas preciosas no seu dia para descansar e relaxar.",
  },
  {
    icon: <Smile className="h-10 w-10 text-primary" />,
    title: "Milhares Aprovaram",
    description:
      "Chega de desespero! Com nosso plano e resumos, você terá a confiança necessária para encarar a prova com tranquilidade.",
  },
];

export function Benefits() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
          <div className="space-y-2">
            <h2 className="text-3xl font-headline font-bold tracking-tighter sm:text-5xl text-white">
              Por Que Escolher Nossos Resumos?
            </h2>
          </div>
        </div>
        <div className="grid gap-10 sm:px-10 md:gap-16 md:grid-cols-3">
          {benefits.map((benefit) => (
            <Card
              key={benefit.title}
              className="flex flex-col items-center text-center shadow-md hover:shadow-xl transition-shadow bg-card/80 backdrop-blur-sm border-0"
            >
              <CardHeader className="items-center">
                <div className="flex items-center justify-center bg-primary/20 text-primary-foreground rounded-full h-16 w-16">
                  {benefit.icon}
                </div>
                <CardTitle className="font-headline text-2xl pt-4 text-white">
                  {benefit.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-white/80">{benefit.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
